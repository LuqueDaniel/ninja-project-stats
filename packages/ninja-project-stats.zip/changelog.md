Project-Stats - Changelog
=========================================

- **Project-Stats 0.2** - (07/21/2013)
        - Added new ignore type files.
        - Changed file table.

- **Project-Stats 0.1** - (03/15/2013)
        - First version of Project-Stats.
