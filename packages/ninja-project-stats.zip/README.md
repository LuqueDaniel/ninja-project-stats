NINJA-IDE - Project-Stats plugin.
===============================================================================================================
**Project-Stats** is a plugin for **[NINJA-IDE](http://ninja-ide.org)**. Project-Stats gets stats of projects.

Version: **0.2**<br />
Licensed under: **GPLv3**

Download packages.
----------------------------------------------------------------------------------------------------------------
**[Download packages](https://github.com/LuqueDaniel/ninja-project-stats/blob/master/packages/ninja-project-stats.zip)**

Changelog.
----------------------------------------------------------------------------------------------------------------
See **[changelog.md](https://github.com/LuqueDaniel/ninja-project-stats/blob/master/changelog.md)** for more information
